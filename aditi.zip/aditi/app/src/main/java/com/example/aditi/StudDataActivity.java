package com.example.aditi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class StudDataActivity extends AppCompatActivity {
    ImageButton btn1,btn2,btn3,btn4,btn5,logout;
    private ListView listView;
    Information info;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stud_data);

        btn1=findViewById(R.id.imageButton);
        btn2=findViewById(R.id.imageButton2);
        btn3=findViewById(R.id.imageButton3);
        btn4=findViewById(R.id.imageButton4);
        btn5=findViewById(R.id.imageButton5);
        logout=findViewById(R.id.imageButton9);

        pd = new ProgressDialog(this);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudDataActivity.this, MainadminActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudDataActivity.this,TokenActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudDataActivity.this, NoticeadminActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StudDataActivity.this, StudDataActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudDataActivity.this, MoreadminActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudDataActivity.this,LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });




        pd.setMessage("Please Wait!");
        pd.show();

        info=new Information();
        listView =(ListView) findViewById(R.id.listView);

        final ArrayList<String> list=new ArrayList<>();



        final ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.user_info,R.id.userinfo,list);

        listView.setAdapter(adapter);
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference().child("Users");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                list.clear();
                pd.dismiss();
                for (DataSnapshot snapshot1:dataSnapshot.getChildren()){
                    info=snapshot1.getValue(Information.class);
                    list.add("NAME\t\t\t\t\t\t\t\t:\t\t"+info.getName().toString()+"\n"+
                            "EMAIL-ID\t\t\t\t\t\t:\t\t"+info.getEmail().toString()+"\n"+
                            "CATEGORY\t\t\t\t:\t\t"+info.getCategory().toString()+"\n"+
                            "MOBILE NO\t\t\t:\t\t"+info.getPhone().toString()+"\n");
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}