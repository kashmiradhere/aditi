package com.example.aditi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;


import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button token ;
    ConstraintLayout expandableView,expandableView2;
    Button arrowBtn,arrowBtn2;
    CardView cardView,cardView2;
    ImageButton imageButton,imageButton2,imageButton3,imageButton4,logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        imageButton=findViewById(R.id.imageButton);
        imageButton2=findViewById(R.id.imageButton2);
        imageButton3=findViewById(R.id.imageButton3);
        imageButton4=findViewById(R.id.imageButton4);
        logout=findViewById(R.id.imageButton9);



        arrowBtn = findViewById(R.id.arrowBtn);
        cardView = findViewById(R.id.cardView);
        expandableView = findViewById(R.id.expandableView);

        arrowBtn2 = findViewById(R.id.arrowBtn2);
        cardView2 = findViewById(R.id.cardView2);
        expandableView2 = findViewById(R.id.expandableView2);



        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,tokenbuttonActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,noticeboardActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,moreActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });



        //Btn1=findViewById(R.id.Btn1);
        // view1=findViewById(R.id.view1);


        arrowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expandableView.getVisibility()==View.GONE){
                    TransitionManager.beginDelayedTransition(cardView, new AutoTransition());
                    expandableView.setVisibility(View.VISIBLE);
                    arrowBtn.setBackgroundResource(R.drawable.dropup);
                } else {
                    TransitionManager.beginDelayedTransition(cardView, new AutoTransition());
                    expandableView.setVisibility(View.GONE);
                    arrowBtn.setBackgroundResource(R.drawable.dropdown);
                }
            }
        });


        arrowBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expandableView2.getVisibility()==View.GONE){
                    TransitionManager.beginDelayedTransition(cardView2, new AutoTransition());
                    expandableView2.setVisibility(View.VISIBLE);
                    arrowBtn2.setBackgroundResource(R.drawable.dropup);
                } else {
                    TransitionManager.beginDelayedTransition(cardView2, new AutoTransition());
                    expandableView2.setVisibility(View.GONE);
                    arrowBtn2.setBackgroundResource(R.drawable.dropdown);
                }
            }
        });



        TextView textview=(TextView)findViewById(R.id.phoneNumber);
        textview.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview2=(TextView)findViewById(R.id.mailNumber);
        textview2.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview3=(TextView)findViewById(R.id.iname3);
        textview3.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview4=(TextView)findViewById(R.id.iname4);
        textview4.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview5=(TextView)findViewById(R.id.iname5);
        textview5.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview6=(TextView)findViewById(R.id.iname6);
        textview6.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview7=(TextView)findViewById(R.id.iname7);
        textview7.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview8=(TextView)findViewById(R.id.iname8);
        textview8.setMovementMethod(LinkMovementMethod.getInstance());

        TextView textview9=(TextView)findViewById(R.id.iname9);
        textview9.setMovementMethod(LinkMovementMethod.getInstance());

    }


}
