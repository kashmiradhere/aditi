package com.example.aditi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    RadioButton btn1,btn2;
    private EditText email,emailid;
    private EditText password,passwordd;
    private Button login;
    private TextView registerUser;

    ProgressDialog pd;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        pd = new ProgressDialog(this);


        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);


        registerUser = findViewById(R.id.register_user);
        btn1 = (RadioButton)findViewById(R.id.radioButton);
        btn2 = (RadioButton)findViewById(R.id.radioButton2);
        mAuth = FirebaseAuth.getInstance();

        registerUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this , RegisterActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               {
                    String txt_email = email.getText().toString();
                    String txt_password = password.getText().toString();

                    if (TextUtils.isEmpty(txt_email) || TextUtils.isEmpty(txt_password)) {
                        Toast.makeText(LoginActivity.this, "Empty Credentials!", Toast.LENGTH_SHORT).show();
                    } else {
                        loginUser(txt_email, txt_password);

                    }
                }

                }
            });
    }

    private void loginUser(String email, String password) {
        pd.setMessage("Please Wait!");
        pd.show();
        mAuth.signInWithEmailAndPassword(email , password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    pd.dismiss();
                   /* Toast.makeText(LoginActivity.this, "Update the profile " +
                            "for better expereince", Toast.LENGTH_SHORT).show();*/

                    if(btn1.isChecked())
                    {
                        startActivity(new Intent(LoginActivity.this , MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));

                    }
                    if(btn2.isChecked()) {

                        startActivity(new Intent(LoginActivity.this , MainadminActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(LoginActivity.this,"Enter valid email id", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void onRadioClick(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        String str="";
        switch(view.getId()) {
            case R.id.radioButton:
                if(checked)
                    str = "Student Selected";
                break;
            case R.id.radioButton2:
                if(checked)
                    str = "Staff Selected";
                break;
        }
    }
}
