package com.example.aditi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {


    private EditText email, emailid;
    private EditText password, passwordd;
    private EditText name;
    private Button register;
    private TextView loginUser;
    private EditText phone;
    private EditText category;
    RadioButton btn1, btn2;
    TableLayout L1, L2;

    private DatabaseReference mRootRef;
    private FirebaseAuth mAuth;

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        passwordd = findViewById(R.id.pass);
        category = findViewById(R.id.category);
        phone = findViewById(R.id.phone);
        emailid = findViewById(R.id.email1);

        register = findViewById(R.id.register);
        loginUser = findViewById(R.id.login_user);


        btn1 = (RadioButton) findViewById(R.id.radioButton);
        btn2 = (RadioButton) findViewById(R.id.radioButton2);
        L1 = (TableLayout) findViewById(R.id.L1);
        L2 = (TableLayout) findViewById(R.id.L2);
        mRootRef = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        pd = new ProgressDialog(this);
        loginUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (btn1.isChecked()) {


                    String txtEmail = email.getText().toString();
                    String txtPassword = password.getText().toString();
                    String nam = name.getText().toString();
                    String phn = phone.getText().toString();
                    String cat=category.getText().toString();


                    if (TextUtils.isEmpty(txtEmail) || TextUtils.isEmpty(txtPassword) || TextUtils.isEmpty(nam) || TextUtils.isEmpty(phn)) {
                        Toast.makeText(RegisterActivity.this, "Empty credentials!", Toast.LENGTH_SHORT).show();
                    } else if (txtPassword.length() < 6) {
                        Toast.makeText(RegisterActivity.this, "Password too short!", Toast.LENGTH_SHORT).show();
                    } else {
                        registerUser(txtEmail, txtPassword, nam, phn, cat);


                    }
                }


                if (btn2.isChecked()) {
                    String Email = emailid.getText().toString();
                    String passwor = passwordd.getText().toString();


                    if (TextUtils.isEmpty(Email) || TextUtils.isEmpty(passwor) ) {
                        Toast.makeText(RegisterActivity.this, "Empty credentials!", Toast.LENGTH_SHORT).show();
                    } else if (passwor.length() < 6) {
                        Toast.makeText(RegisterActivity.this, "Password too short!", Toast.LENGTH_SHORT).show();
                    } else {
                        registerUseradmin(Email, passwor);

                    }
                }                    String cat = category.getText().toString();


            }
        });
    }

    private void registerUser(final String email, String password, final String name, final String phn, final String cat) {

        pd.setMessage("Please Wait!");
        pd.show();

        mAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Information info = new Information();
                info.setEmail(email);
                info.setName(name);
                info.setCategory(cat);
                info.setPhone(phn);


                mRootRef.child("Users").child(mAuth.getCurrentUser().getUid()).setValue(info).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            pd.dismiss();
                            /*Toast.makeText(RegisterActivity.this, "Update the profile " +
                                    "for better expereince", Toast.LENGTH_SHORT).show();*/
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);

                            finish();
                        }
                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(RegisterActivity.this,"Enter valid email id", Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void onRadioClick(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        String str = "";
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radioButton:
                if (checked)
                    L1.setVisibility(View.VISIBLE);
                L2.setVisibility(View.GONE);
                break;
            case R.id.radioButton2:
                if (checked)
                    L2.setVisibility(View.VISIBLE);
                L1.setVisibility(View.GONE);
                break;
        }
        //Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }


    private void registerUseradmin(final String email, String password) {

        pd.setMessage("Please Wail!");
        pd.show();

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>(){
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {



                        if (task.isSuccessful()) {
                            pd.dismiss();
                            /*Toast.makeText(RegisterActivity.this, "Update the profile " +
                                    "for better expereince", Toast.LENGTH_SHORT).show();*/
                            Intent intent = new Intent(RegisterActivity.this, MainadminActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);

                            finish();
                        }

                }


        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(RegisterActivity.this,"Enter valid email id", Toast.LENGTH_SHORT).show();
            }
        });

    }
}







